<?php
$directorio = opendir("./erp/documents/produit/Igenix_Desinfectante"); //ruta actual
while ($archivo = readdir($directorio)) //obtenemos un archivo y luego otro sucesivamente
{
    if (is_dir($archivo))//verificamos si es o no un directorio
    {
        //echo "[".$archivo . "]<br />"; //de ser un directorio lo envolvemos entre corchetes
        
        $image= "/erp/documents/produit/Igenix_Desinfectante/" . $archivo;  
        

        /*$ext = substr($image, -3); 
        //header("Content-Type: image/".$ext); 
       
        $image64 =  base64_encode($str);
        echo "<img src='".$image64."'>";
        echo file_get_contents($image, true);*/

      
        /*
        echo readfile($image); */
    }
    else
    {
        
        
        echo $archivo . "<br />";
    echo $img = "/erp/documents/produit/Igenix_Desinfectante/" . $archivo;
   echo $dat = base64_encode(file_get_contents($img));
    $src = 'data:'.mime_content_type($img).';base64,'.$dat;
    
    echo "<img src=\"$src\">";   
    }
}
?>