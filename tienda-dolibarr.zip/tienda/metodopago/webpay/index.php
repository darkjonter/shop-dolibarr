<!DOCTYPE HTML>
<html>
<head>
<title>Sistema de pago WebPay Plus Cloud</title>
<meta name="description" content="Sistema de pago Webpay plus"/>
<meta name="keywords" content="webpay plus, joomlaempresa"/>
<meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
<link rel="stylesheet" type="text/css" href="css/siimple.css"/>
</head>
<body>
<h1>Sistema de pagos Online Webpay Plus</h1>

<table border="0" style="width:100%">
  <tr>
    <td><h3><a href="ingreso.php">Ingresar reserva</a></h3></td>
    <td><h3><a href="lista_reservas.php">Lista de Reservas</a></h3></td> 
    <td><h3><a href="lista_transacciones.php">Lista de transacciones</a></h3></td>
  </tr>
</table>
</body>
</html>