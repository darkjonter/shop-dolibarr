<form action="chao.php" method="POST">
    <input type="text" name="hehe" value="holahola">
    <input type="submit">
</form> 