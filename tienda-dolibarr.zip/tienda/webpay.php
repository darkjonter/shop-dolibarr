<?php 
if($_POST['id_cliente']){
    $id_cliente = $_POST['id_cliente'];
    include('include/functions.php');
    $pre_order = save_order($id_cliente);
    header('Location: metodopago/webpay/tbk-normal.php?id='.$pre_order);
}
else{
    echo '<h1>NO SE ENCUENTRA ID DE CLIENTE</h1>';
}

?>
<pre>
Orden: aqui se genera la orden y este mismo archivo redireccionara a webpay.
- Una vez se complete el pago en webpay la orden debe validarse con el id que tenemos aqui, la funcion para validar ya existe solo necesitamos el webpay.
-Una vez validada la orden aparecera en el ERP para su vista ya que ahi cambia a orden "validada" supongo que eso es como si estuviera "pagada".</pre>