<html>
    <body>
        <form action="cartAction.php" method="POST">
            <input type="hidden" name="id" value="1">
            <input type="hidden" name="cantidad" value="1">
            <input type="hidden" name="action" value="addToCart">
            <input type="submit">
        </form>
    </body>
</html>